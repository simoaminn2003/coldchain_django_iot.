from django.shortcuts import render
from django.http import JsonResponse
from .models import Dht11

def dashboard(request):
    return render(request, 'DHT/index.html')

def chart_data(request):
    measures = Dht11.objects.all().order_by('-date')[:20]
    measures_list = list(reversed(list(measures)))
    
    labels = [m.date.strftime('%H:%M:%S') for m in measures_list]
    temperatures = [m.temperature for m in measures_list]
    humidities = [m.humidity for m in measures_list]
    
    return JsonResponse({
        'labels': labels,
        'temperatures': temperatures,
        'humidities': humidities,
    })
