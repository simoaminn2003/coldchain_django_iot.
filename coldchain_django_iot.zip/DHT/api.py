from rest_framework import generics
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.core.mail import send_mail
from django.conf import settings
import telebot

from .models import Dht11
from .serializers import DHT11serialize

@api_view(['GET'])
def Dlist(request):
    all_data = Dht11.objects.all().order_by('-date')
    data = DHT11serialize(all_data, many=True).data
    return Response({'data': data})

class Dhtviews(generics.CreateAPIView):
    queryset = Dht11.objects.all()
    serializer_class = DHT11serialize

    def perform_create(self, serializer):
        data = serializer.save()
        temperature = data.temperature

        if temperature > 25:
            message = f"Alerte! Temperature elevee : {temperature} °C"
            try:
                send_mail(
                    subject="Alerte Temperature Cold Chain",
                    message=message,
                    from_email=settings.EMAIL_HOST_USER,
                    recipient_list=[settings.EMAIL_HOST_USER],
                    fail_silently=True
                )
            except Exception as e:
                print(f"Erreur Email: {e}")

            try:
                bot = telebot.TeleBot(settings.TELEGRAM_TOKEN)
                bot.send_message(settings.TELEGRAM_CHAT_ID, message)
            except Exception as e:
                print(f"Erreur Telegram: {e}")
